package files;

public class Resources {
	
	public static String placePOSTData()
	{
		String resource="/maps/api/place/add/json";
		return resource;
	}

}
